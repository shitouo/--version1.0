var app = getApp();
Page({
    data : {
        loadingHidden : "true",
        chapterId : null,
        cartoonsList : []
    },
    onReady: function(){
    var that = this
    wx.setNavigationBarTitle({
      title: that.data.options.name
    })
    },
    onLoad : function(options){
        this.setData({
           name : options.name,
           options : options
        });
        var that = this;
        wx.request({
            url : 'http://japi.juhe.cn/comic/chapter',
            data : {
            	key : '36b524258d2b571b9d32a5f6e3fb5693',
                comicName : that.data.name
            },
            header : {
                'Content-Type': 'application/json'
            },
            success : function(res){
                that.setData({
                    chapterId : res.data.result.chapterList[0].id
                });
                wx.request({
                    url : 'http://japi.juhe.cn/comic/chapterContent',
                    data : {
                        key : '36b524258d2b571b9d32a5f6e3fb5693',
                        comicName : that.data.name,
                        id : that.data.chapterId
                    },
                    header : {
                        'Content-Type': 'application/json'
                    },
                    success : function(res){
                        that.setData({
                            cartoonsList : res.data.result.imageList
                        })
                    }
                })
            }
        });
    }
})