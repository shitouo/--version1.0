var app = getApp();
Page({
    data : {
        imgUrls : [
            {url:"../../image/movieCover.jpg", text : "火热的影讯", state : false},
            {url:"../../image/booksCover.jpg", text : "资深的小说", state : false},
            {url:"../../image/cartoonCover.jpg", text : "趣味的漫画", state : false},
            {url:"../../image/musicCover.jpg", text : "唯美的音乐", state : true},    
        ]
    }
})
